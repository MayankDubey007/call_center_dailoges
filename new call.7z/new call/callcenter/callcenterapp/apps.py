from django.apps import AppConfig


class CallcenterappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'callcenterapp'
